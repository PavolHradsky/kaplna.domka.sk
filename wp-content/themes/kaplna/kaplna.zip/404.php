<?php get_header(); ?>
<div class="content flex flex-col lg:max-w-3xl mx-10 lg:mx-auto py-10">
    <div class="posts flex flex-col gap-4">
        <h1>404</h1>
    </div>
</div>
<?php get_footer(); ?>