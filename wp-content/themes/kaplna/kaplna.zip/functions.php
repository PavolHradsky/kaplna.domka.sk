<?php
add_theme_support( 'post-thumbnails' );
add_theme_support( 'menus' );
